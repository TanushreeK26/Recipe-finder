package recipefinder;

import java.sql.*;
import java.util.*;

public class RecipeFinder {
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n?? Recipe Finder ??");
            System.out.println("1. Add Recipe");
            System.out.println("2. Search by Ingredients");
            System.out.println("3. Delete Recipe");
            System.out.println("4. View All Recipes");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1 -> addRecipe();
                case 2 -> searchByIngredients();
                case 3 -> deleteRecipe();
                case 4 -> viewAll();
                case 5 -> {
                    System.out.println("?? Exiting... Happy Cooking!");
                    return;
                }
                default -> System.out.println("?? Invalid choice. Try again.");
            }
        }
    }

    private static void addRecipe() {
        try (Connection conn = DBUtil.getConnection()) {
            System.out.print("Enter recipe name: ");
            String name = scanner.nextLine();
            System.out.print("Enter ingredients (comma-separated): ");
            String ingredients = scanner.nextLine();
            System.out.print("Enter instructions: ");
            String instructions = scanner.nextLine();

            String sql = "INSERT INTO recipes (name, ingredients, instructions) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, ingredients);
            stmt.setString(3, instructions);
            stmt.executeUpdate();

            System.out.println("? Recipe added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void searchByIngredients() {
        try (Connection conn = DBUtil.getConnection()) {
            System.out.print("Enter ingredients (comma-separated): ");
            String input = scanner.nextLine().toLowerCase();
            Set<String> inputSet = new HashSet<>(Arrays.asList(input.split("\\s*,\\s*")));

            String sql = "SELECT * FROM recipes";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            boolean found = false;
            while (rs.next()) {
                String recipeIngredients = rs.getString("ingredients").toLowerCase();
                Set<String> recipeSet = new HashSet<>(Arrays.asList(recipeIngredients.split("\\s*,\\s*")));

                Set<String> common = new HashSet<>(inputSet);
                common.retainAll(recipeSet);
                double matchPercentage = (double) common.size() / recipeSet.size() * 100;

                if (!common.isEmpty()) {
                    found = true;
                    System.out.printf("\n?? Match: %.2f%%\n", matchPercentage);
                    System.out.println("ID: " + rs.getInt("id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Ingredients: " + rs.getString("ingredients"));
                    System.out.println("Instructions: " + rs.getString("instructions"));
                }
            }
            if (!found) {
                System.out.println("? No recipes matched your ingredients.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteRecipe() {
        try (Connection conn = DBUtil.getConnection()) {
            System.out.print("Enter Recipe ID to delete: ");
            int id = Integer.parseInt(scanner.nextLine());

            String sql = "DELETE FROM recipes WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            int rows = stmt.executeUpdate();

            if (rows > 0) {
                System.out.println("??? Recipe deleted successfully.");
            } else {
                System.out.println("? No recipe found with that ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAll() {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT * FROM recipes";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            boolean hasData = false;
            while (rs.next()) {
                hasData = true;
                System.out.println("\n?? Recipe:");
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Ingredients: " + rs.getString("ingredients"));
                System.out.println("Instructions: " + rs.getString("instructions"));
            }
            if (!hasData) {
                System.out.println("?? No recipes found in the database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
